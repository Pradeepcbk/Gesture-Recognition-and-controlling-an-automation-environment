object Screen '($java-object (de.mmis.devices.eib.devices.ScreenImpl ("3/1/61") ("3/2/61") "3/5/61" false))' 
addDevice de.mmis.devices.eib.EIB * "(setEIBGateway @PROXY @ID)" Socket
invoke "(moveToBottomPosition)"
quit