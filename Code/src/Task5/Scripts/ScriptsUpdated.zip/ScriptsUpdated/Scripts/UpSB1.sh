object Screen '($java-object (de.mmis.devices.eib.devices.ScreenImpl ("3/1/59") ("3/2/59") "3/5/59" false))' 
addDevice de.mmis.devices.eib.EIB * "(setEIBGateway @PROXY @ID)" Socket
invoke "(moveToTopPosition)"
quit