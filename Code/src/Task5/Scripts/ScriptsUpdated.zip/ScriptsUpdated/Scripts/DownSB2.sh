object Screen '($java-object (de.mmis.devices.eib.devices.ScreenImpl ("3/1/60") ("3/2/60") "3/5/60" false))' 
addDevice de.mmis.devices.eib.EIB * "(setEIBGateway @PROXY @ID)" Socket
invoke "(moveToBottomPosition)"
quit