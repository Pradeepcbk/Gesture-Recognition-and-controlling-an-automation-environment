object Screen '($java-object (de.mmis.devices.eib.devices.ScreenImpl ("3/1/63") ("3/2/63") "3/5/63" false))' 
addDevice de.mmis.devices.eib.EIB * "(setEIBGateway @PROXY @ID)" Socket
invoke "(moveToBottomPosition)"
quit