object Screen '($java-object (de.mmis.devices.eib.devices.ScreenImpl ("3/6/81") ("3/2/81") "3/5/81" false))' 
addDevice de.mmis.devices.eib.EIB * "(setEIBGateway @PROXY @ID)" Socket
invoke "(moveToTopPosition)"
quit