object Screen '($java-object (de.mmis.devices.eib.devices.ScreenImpl ("3/6/83") ("3/2/83") "3/5/83" false))' 
addDevice de.mmis.devices.eib.EIB * "(setEIBGateway @PROXY @ID)" Socket
invoke "(moveToTopPosition)"
quit