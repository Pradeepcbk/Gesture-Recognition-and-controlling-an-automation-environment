object Screen '($java-object (de.mmis.devices.eib.devices.ScreenImpl ("3/6/82") ("3/2/82") "3/5/82" false))' 
addDevice de.mmis.devices.eib.EIB * "(setEIBGateway @PROXY @ID)" Socket
invoke "(moveToTopPosition)"
quit