#!/usr/bin/env bash

java -classpath .:log4j-core-2.1.jar:log4j-api-2.1.jar:SmartLab-full.jar de.mmis.utilities.genericPublisher.GenericPublisherMain --file "UpSB1.sh" 

